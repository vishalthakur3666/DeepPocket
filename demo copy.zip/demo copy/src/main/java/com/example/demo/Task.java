package com.example.demo;

import java.util.List;

class Task implements Runnable{
    private String username, csvFilePath;
    private List<String> requestedQueryNames;

    public Task(String username, String csvFilePath, List<String> requestedQueryNames) {
        this.username = username;
        this.csvFilePath = csvFilePath;
        this.requestedQueryNames = requestedQueryNames;
    }

    @Override
    public void run() {
        try {
            LargeFileProcessor largeFileProcessor = new LargeFileProcessor(username);
            largeFileProcessor.insertFromCsvFile(csvFilePath);
            for(String requestedQueryName:requestedQueryNames){
                int count = largeFileProcessor.getProductCount(requestedQueryName);
                System.out.println("For user "+username+" for name "+requestedQueryName+" count="+count);
            }
            largeFileProcessor.closeSession(username);

        } catch (Exception e) {
            System.out.println("line 37\n" + e.getMessage());
        }
    }
}