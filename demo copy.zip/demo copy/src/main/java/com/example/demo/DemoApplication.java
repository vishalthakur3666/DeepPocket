package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.sql.*;
import java.util.*;

@SpringBootApplication
public class DemoApplication {
	public static void main(String[] args) throws SQLException {
		SpringApplication.run(DemoApplication.class, args);
		ExecutorService executor = Executors.newFixedThreadPool(10);
		String csvFilePath = "products.csv";
		executor.submit(new Task("User1", csvFilePath, Arrays.asList("David Wright", "John Buckley")));
		executor.submit(new Task("User2", csvFilePath, Arrays.asList("Anthony Burch", "Albert Einstein")));
		executor.shutdown();
		System.out.println("terminate now");
	}
}
