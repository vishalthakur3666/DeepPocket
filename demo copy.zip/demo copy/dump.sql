CREATE TABLE product (
  name varchar(50),
  sku varchar(50) primary key,
  description text
);
CREATE TABLE freqtable (
    name varchar(50) primary key,
    count int
);