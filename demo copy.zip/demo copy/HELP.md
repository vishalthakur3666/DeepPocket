# Getting Started


cd demo
docker build -t demo .
docker run --rm -it demo:latest

