package com.example.demo;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.*;
import java.sql.*;
import java.util.*;


class LargeFileProcessor {

    private Connection connection;
    private static Set<String> sharedSkuSet = new HashSet<>();

    public LargeFileProcessor(Connection connection) throws SQLException, ClassNotFoundException {
        this.connection = connection;
        if(sharedSkuSet.isEmpty()){
            loadProductDataFromDB();
        }
    }

    private int getProductCount(String productNameSearched) throws SQLException {
        int productCount = 0;
        String query =String.format("SELECT no_of_products from aggregate where name='%s'", productNameSearched);
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        ResultSet resultSet =preparedStatement.executeQuery();
        if(resultSet.next()){
            productCount = resultSet.getInt("no_of_products");
        }
        resultSet.close();
        return productCount;
    }

    private CSVParser getProductDataFromFile(String csvFilePath) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new FileReader(csvFilePath));
        return CSVParser.parse(bufferedReader, CSVFormat.EXCEL.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());
    }
    private void loadProductDataFromDB() throws SQLException {
        String query = "SELECT name,sku,description FROM product";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        ResultSet resultSet =preparedStatement.executeQuery();

        while(resultSet.next())
        {
            String sku =resultSet.getString("sku");//enum
            synchronized (sharedSkuSet){
                sharedSkuSet.add(sku);
            }
        }
        resultSet.close();
    }

    private boolean isSkuUnique(String sku, Set<String> skuSet){
        if(skuSet.contains(sku)){
            return false;
        }
        synchronized (sharedSkuSet){
            if(sharedSkuSet.contains(sku)){
                return false;
            }
            sharedSkuSet.add(sku);
        }
        skuSet.add(sku);
        return true;
    }
    public void insertFromCsvFile(String csvFilePath) {
        try {
            checkEmptyString(csvFilePath);
            System.out.println("reading file now");
            CSVParser csvParser = getProductDataFromFile(csvFilePath);
            System.out.println("file reading complete. Initiating insert. Please wait.\nThis takes around 2-3 minutes for a 90MB csv file.");
            ArrayList<Product> products = new ArrayList<>();
            Set<String> skuSet = new HashSet<>();
            HashMap<String, Integer> productNameFrequencyHashMap = new HashMap<>();

            for (CSVRecord record : csvParser) {
                String sku = record.get(1);
                if (isSkuUnique(sku, skuSet)) {
                    addProductRecord(record, productNameFrequencyHashMap, products);
                }
            }
            writeProductsToDB(products);
            insertIntoFrequencyTable(productNameFrequencyHashMap);
        }
        catch (Exception e){
            //e.printStackTrace();
        }
    }

    private void checkEmptyString(String csvFilePath) throws Exception{
        if(csvFilePath==null || csvFilePath.length()==0){
            throw new Exception();
        }
    }

    private void addProductRecord(CSVRecord record, HashMap<String,Integer> productNameFrequencyHashMap, ArrayList<Product> products){
        Product product = new Product(record);
        String productName = record.get(0);
        if(productNameFrequencyHashMap.containsKey(productName))
            productNameFrequencyHashMap.put((productName), productNameFrequencyHashMap.get(productName)+1);
        else
            productNameFrequencyHashMap.put(productName,1);
        products.add(product);
    }

    private void writeProductsToDB(ArrayList<Product> products) throws SQLException {
        String insertQueryString = "INSERT INTO product(name,sku,description) VALUES (?,?,?)";
        PreparedStatement insertStatement = connection.prepareStatement(insertQueryString);
        for (Product product : products) {
            insertStatement.setString(1, product.getName());
            insertStatement.setString(2, product.getSku());
            insertStatement.setString(3,product.getDescription());
            insertStatement.addBatch();
        }
        insertStatement.executeBatch();
        System.out.printf("inserted %d rows into product table", products.size());
    }

    private synchronized void insertIntoFrequencyTable(HashMap<String, Integer> productNameFrequencyHashMap) throws SQLException {
        String sql = "INSERT INTO aggregate(name,no_of_products) VALUES (?,?) on duplicate key UPDATE no_of_products = no_of_products + ?";
        PreparedStatement upsertStmt = connection.prepareStatement(sql);

        for(Map.Entry<String,Integer> entry: productNameFrequencyHashMap.entrySet()){
            String productName = entry.getKey();
            Integer productCount = entry.getValue();
            upsertStmt.setString(1, productName);
            upsertStmt.setInt(2, productCount);
            upsertStmt.setInt(3, productCount);
            upsertStmt.addBatch();
        }

        upsertStmt.executeBatch();
        System.out.printf("upserted %d rows into frequency table", productNameFrequencyHashMap.size());
    }

    public void queryRequestedNames(List<String> requestedQueryNames) {
        try {
            checkNullList(requestedQueryNames);
            for (String requestedQueryName : requestedQueryNames) {
                int count = getProductCount(requestedQueryName);
                System.out.println(" for name " + requestedQueryName + " count=" + count);
            }
        }
        catch (Exception e){
            //e.printStackTrace();
        }
    }

    private void checkNullList(List<String> requestedQueryNames) throws Exception {
        if(requestedQueryNames == null){
            throw new Exception();
        }
    }

    public synchronized void updateName(String sku, String productNewName) {
        try {
            validateSkuExists(sku);
            String skuInfo = String.format("select * from product where sku='%s')", sku);
            String reduceCount = String.format("update aggregate set no_of_products=no_of_products-1 where name in (select name from product where sku='%s')", sku);
            String updateProduct = String.format("update product set name = '%s' where sku='%s'",productNewName,sku);

            System.out.println("before update..");
            System.out.println(connection.prepareStatement(skuInfo).executeQuery());
            connection.prepareStatement(reduceCount).executeQuery();
            connection.prepareStatement(updateProduct).executeQuery();
            System.out.println("updated record....\nafter update..");
            System.out.println(connection.prepareStatement(skuInfo).executeQuery());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private synchronized void validateSkuExists(String sku) throws Exception {
        if(!sharedSkuSet.contains(sku)){
            throw new Exception("No such skew.");
        }
    }
}
