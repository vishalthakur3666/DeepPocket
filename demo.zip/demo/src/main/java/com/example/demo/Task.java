package com.example.demo;

import java.sql.Connection;
import java.util.List;

class Task implements Runnable{
    private String csvFilePath;
    private List<String> requestedQueryNames;
    Connection connection;

    public Task(String csvFilePath, List<String> requestedQueryNames, Connection connection) {
        this.csvFilePath = csvFilePath;
        this.requestedQueryNames = requestedQueryNames;
        this.connection = connection;
    }

    @Override
    public void run() {
        try {
            LargeFileProcessor largeFileProcessor = new LargeFileProcessor(connection);
            largeFileProcessor.insertFromCsvFile(csvFilePath);
            largeFileProcessor.queryRequestedNames(requestedQueryNames);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}