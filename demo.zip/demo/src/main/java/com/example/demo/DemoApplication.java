package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.sql.*;
import java.util.*;

@SpringBootApplication
public class DemoApplication {
	private final String MY_SQL_URL = "jdbc:mysql://host.docker.internal:3306/mysql";
	private final String ROOT_USER = "root";
	private final String JDBC_DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
	Connection connection;


	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		SpringApplication.run(DemoApplication.class, args);

		DemoApplication demoApplication = new DemoApplication();
		demoApplication.establishDbConnection();
		demoApplication.createTables();
		demoApplication.startQueryProcessing();

	}

	private void startQueryProcessing() {
		ExecutorService executor = Executors.newFixedThreadPool(8);
		Scanner scanner = new Scanner(System.in);
		while(true){
			System.out.println("What do you like to do? \n i:insert record \n f:fetch record \n u:update record");
			String choice = scanner.nextLine();
			if(choice.startsWith("i")){
				//insert
				System.out.println("enter csv file name");
				String csvFilePath = scanner.nextLine();
				executor.submit(new Task("app/"+ csvFilePath, null, connection));
			}
			else if(choice.startsWith("f")){
				//fetch
				System.out.println("enter person name");
				String person = scanner.nextLine();
				executor.submit(new Task(null,  Arrays.asList(person), connection));
			}
			else if(choice.startsWith("u")){
				//update
				System.out.println("enter product sku");
				String sku = scanner.nextLine();
				System.out.println("enter new name for this product");
				String name = scanner.nextLine();
				Task task = new UpdateTask(connection, sku, name);
				executor.submit(task);
			}
			else {
				//bad  choice
				System.out.println("Sorry, didn't get that. try again..");
				continue;
			}
		}
	}

	private void createTables() throws SQLException {
		connection.prepareStatement("create table if not exists product(name varchar(50) not null, sku varchar(50) not null, description text, primary key(sku))").executeUpdate();
		connection.prepareStatement("create table if not exists aggregate(name varchar(50) not null, no_of_products int, primary key(name))").executeUpdate();
	}

	private String getPassword() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter your MYSQL root password");
		String password = scanner.nextLine();
		if(password.length()==0){
			System.out.println("password cannot be blank. try again");
			return getPassword();
		}
		return password;
	}
	private void establishDbConnection() throws ClassNotFoundException, SQLException {
		System.out.println("Connecting to MYSQL Server...");
		Class.forName(JDBC_DRIVER_NAME);
		String db_admin_password = "Drizzly184#FogRide";//getPassword();
		connection = DriverManager.getConnection(MY_SQL_URL, ROOT_USER, db_admin_password);
		System.out.println("connected to MYSQL Server successfully");
		connection.setAutoCommit(true);
	}
}
