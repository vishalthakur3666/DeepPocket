package com.example.demo;

import java.sql.Connection;

class UpdateTask extends Task{
    private String sku,productNewName;

    public UpdateTask(Connection connection, String sku, String productNewName) {
        super(null, null, connection);
        this.sku = sku;
        this.productNewName = productNewName;
    }

    @Override
    public void run() {
        try {
            LargeFileProcessor largeFileProcessor = new LargeFileProcessor(connection);
            largeFileProcessor.updateName(sku, productNewName);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}