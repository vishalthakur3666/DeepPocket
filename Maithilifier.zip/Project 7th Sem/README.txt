Step 1: Make sure you have IDLE or similar platform for executing python script.

Step 2: Run "maithili parser" using IDLE.
