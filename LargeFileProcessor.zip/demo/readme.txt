Download products.csv from
https://drive.google.com/file/d/1_X94ah7TLbtN-CY1NMx9XXri23JhjCg3/view?usp=sharing
Add it to demo/app

Install docker

Run : 
cd ~/Downloads/demo
docker build -t demo .
docker run -v "$(pwd)"/app:/app demo:latest
